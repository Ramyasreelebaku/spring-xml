package com.hexa.spring.com.hexa.spring1;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Book b=new Book();
        System.out.println(b.toString());
    }
}
